import {fields,validate} from '../../../lib/enquiry.js'
import {products} from '../../../lib/content.js'
const maxBytes=16384
const unavailable='Online enquiries are temporarily unavailable. Please try again later.'
function failure(error,status){return Response.json({error},{status})}
async function readPayload(request){
  const reader=request.body?.getReader()
  if(!reader) return null
  const decoder=new TextDecoder()
  let size=0
  let body=''
  while(true){
    const {done,value}=await reader.read()
    if(done) break
    size+=value.byteLength
    if(size>maxBytes){await reader.cancel();return null}
    body+=decoder.decode(value,{stream:true})
  }
  return JSON.parse(body+decoder.decode())
}
export async function POST(request){
  const fetchSite=request.headers.get('sec-fetch-site')
  if(fetchSite && fetchSite!=='same-origin') return failure('Invalid request origin.',403)
  if(!request.headers.get('content-type')?.startsWith('application/json')) return failure('Invalid request format.',415)
  let input
  try{input=await readPayload(request)}catch{return failure('Invalid request format.',400)}
  if(!input || input.website!=='' || typeof input.id!=='string' || !/^[a-f0-9-]{36}$/i.test(input.id)) return failure('Invalid enquiry submission.',400)
  const {data,error}=validate(input)
  if(error) return failure(error,422)
  const {RESEND_API_KEY,QUOTE_FROM_EMAIL,QUOTE_TO_EMAIL}=process.env
  if(!RESEND_API_KEY || !QUOTE_FROM_EMAIL || !QUOTE_TO_EMAIL) return failure(unavailable,503)
  const product=products.find(item=>item.id===data.gas)
  const text=fields.map(([key,label])=>label+': '+(key==='gas'?product.name:data[key])).join('\n')
  try{
    const response=await fetch('https://api.resend.com/emails',{
      method:'POST',
      headers:{Authorization:'Bearer '+RESEND_API_KEY,'Content-Type':'application/json','Idempotency-Key':'quote/'+input.id},
      body:JSON.stringify({from:QUOTE_FROM_EMAIL,to:[QUOTE_TO_EMAIL],subject:'New website quotation enquiry',text,...(data.email && {reply_to:data.email})}),
      signal:AbortSignal.timeout(10000)
    })
    if(!response.ok || !(await response.json()).id) return failure('We couldn’t submit your enquiry. Please try again.',502)
    return Response.json({accepted:true},{status:202})
  }catch{return failure('We couldn’t confirm your submission. Please try again.',502)}
}
