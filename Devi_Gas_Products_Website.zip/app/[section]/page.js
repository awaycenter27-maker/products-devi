import {notFound} from 'next/navigation'
import {pages, intro, name, siteUrl, products} from '../../lib/content'
import {Photo, QuoteBanner, Leadership, ProductRows, FactoryRows, CompanyRows} from '../../components/Sections'
import QuoteForm from '../../components/QuoteForm'
export const dynamicParams = false
export function generateStaticParams(){ return Object.keys(pages).map(section=>({section})) }
export async function generateMetadata({params}){
  const {section}=await params
  if(!Object.hasOwn(pages,section)) return {}
  const [title,description]=pages[section]
  const base=siteUrl()
  return {title,description,...(base && {alternates:{canonical:base+'/'+section}}),openGraph:{title,description,...(base && {images:['/images/exterior.webp']})}}
}
function Contacts(){
  const {SALES_PHONE, SALES_WHATSAPP, SALES_EMAIL, OFFICE_ADDRESS}=process.env
  if(![SALES_PHONE,SALES_WHATSAPP,SALES_EMAIL,OFFICE_ADDRESS].some(Boolean)) return null
  return <address className="contact-details">
    {SALES_PHONE && <a href={'tel:'+SALES_PHONE.replace(/[^+\d]/g,'')}>{SALES_PHONE}</a>}
    {SALES_WHATSAPP && <a href={'https://wa.me/'+SALES_WHATSAPP.replace(/\D/g,'')}>WhatsApp sales <span className="diagonal" aria-hidden="true"/></a>}
    {SALES_EMAIL && <a href={'mailto:'+SALES_EMAIL}>{SALES_EMAIL}</a>}
    {OFFICE_ADDRESS && <p>{OFFICE_ADDRESS}</p>}
  </address>
}
export default async function Page({params,searchParams}){
  const {section}=await params
  if(!Object.hasOwn(pages,section)) notFound()
  const [title,description]=pages[section]
  const gas=section==='quote'?(await searchParams).gas:null
  return <>
    <section className="page-head"><div className="wrap"><p className="eyebrow">Industrial gases / Kolkata</p><h1>{title}</h1><p className="lede">{description}</p></div></section>
    {section==='about' && <><section className="section wrap feature"><Photo id="plant"/><div><h2>Industrial gases in West Bengal</h2><p>{intro}</p><p>Our factory locations are in Gosridi and Junglepur in Howrah, and in Durgapur. Our group companies include {name}, Prestige Properties Pvt Ltd, and Rajasthan Fertilisers &amp; Chemicals Corporation Ltd.</p></div></section><Leadership/></>}
    {section==='products' && <section className="section wrap split"><figure><Photo id="filling"/><figcaption>Industrial oxygen cylinder filling area</figcaption></figure><ProductRows full/></section>}
    {section==='factories' && <section className="section wrap"><FactoryRows/><h2 className="gallery-title">From our operations</h2><div className="gallery">{['exterior','plant','filling'].map(id=><Photo key={id} id={id} sizes="(max-width: 760px) 100vw, 30vw"/>)}</div></section>}
    {section==='companies' && <section className="section wrap split"><figure><Photo id="plant"/><figcaption>From our industrial operations</figcaption></figure><CompanyRows/></section>}
    {section==='quote' ? <section className="section wrap split enquiry"><div><h2>Sales enquiries</h2><p>Share the gas you need, the estimated quantity and where you need it delivered. Include a phone number or email so we can get back to you.</p><Contacts/></div><QuoteForm key={gas} gas={products.some(p=>p.id===gas)?gas:''}/></section>:<QuoteBanner/>}
  </>
}
